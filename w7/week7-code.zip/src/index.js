import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import { BrowserRouter as Router, Route } from "react-router-dom";
//import App from './App';
//import App from './FlavorForm';
//import App from './Reservation';
//import App from './TemperatureConversionExample';
//import App from './BasicRoutingTest';
//import App from './DynamicRoutingExample';
import App from './NestedRoutingExample';
//import App from './DynamicRoutingTest';


ReactDOM.render(<App />, document.getElementById('root'));
